
document.getElementById("chat-button").addEventListener("click", function() {
    const widget = document.getElementById("chat-widget");
    widget.style.display = widget.style.display === "none" ? "block" : "none";
});
